"""
Synthetic "financial world" for a grounded personal-finance assistant.

Two outputs that agree with each other
--------------------------------------
1. Card events (streaming): generate_transaction() returns EXACTLY the 12 fields
   of the CardTransactionEvent Avro schema. Nothing about schema changed.
2. Reference tables (batch/slowly changing): build_reference_tables() returns
   pandas DataFrames: customer_profile, customer_preferences, bank_accounts,
   demat_holdings, mf_holdings, loans, securities, mf_schemes.

Consistency is by construction: every customer is one persona (income, age,
risk appetite, goals). Card spend volume, balances, SIPs, holdings and loans
are all derived from that persona, so a question like "can I afford a 1.5L
laptop?" has an answer that is coherent across the stream and the tables.

NOTE: securities prices, NAVs and returns are SYNTHETIC. Do not treat them
as market data.
"""
import math
import time
import uuid
import random
from datetime import datetime, timezone

import pandas as pd

SEED = 11
rnd = random.Random(SEED)

DAY_MS = 86_400_000
IST_MS = 19_800_000
NOW_MS = int(time.time() * 1000)

# ----------------------------------------------------------------------
# Reference data (event field VALUES; the schema itself is untouched)
# ----------------------------------------------------------------------
CATEGORIES = ["retail", "electronics", "travel", "dining", "grocery"]
CARD_TYPES = ["Visa", "MasterCard", "RuPay", "Amex"]
CARD_W = [40, 22, 30, 8]

# typical single-ticket size (INR) at income ~ 62k/month
MEDIAN_INR = {"grocery": 650, "dining": 800, "retail": 1800,
              "travel": 3200, "electronics": 6000}
# how often each category is chosen (count share), before personal favourites
BASE_W = {"grocery": 35, "dining": 30, "retail": 20, "travel": 10, "electronics": 5}
TICKET_SIGMA = 0.6

# ordered by popularity (head of the list is most used)
MERCH_IN = {
    "dining": ["Swiggy", "Zomato", "Starbucks", "Domino's", "McDonald's", "Haldiram's",
               "Barbeque Nation", "Cafe Coffee Day", "Social", "Wow! Momo"],
    "grocery": ["BigBasket", "Blinkit", "DMart", "Zepto", "Reliance Smart",
                "More Supermarket", "Nature's Basket", "Spencer's"],
    "retail": ["Amazon", "Flipkart", "Myntra", "Ajio", "Westside", "Lifestyle",
               "Pantaloons", "Nykaa", "Decathlon", "IKEA"],
    "travel": ["Uber", "IRCTC", "MakeMyTrip", "IndiGo", "Ola", "Air India",
               "redBus", "Cleartrip", "Goibibo", "Yatra"],
    "electronics": ["Croma", "Reliance Digital", "Vijay Sales", "Apple Store India",
                    "Samsung Store", "Poorvika"],
}
MERCH_GLOBAL = {
    "dining": ["Starbucks", "McDonald's", "Subway", "Local Restaurant"],
    "grocery": ["Local Supermarket", "7-Eleven", "Carrefour"],
    "retail": ["Zara", "H&M", "Uniqlo", "Duty Free"],
    "travel": ["Uber", "Airbnb", "Booking.com", "Emirates", "Singapore Airlines"],
    "electronics": ["Apple Store", "Best Buy", "Duty Free Electronics"],
}
FOREIGN = {"US": ("USD", 83.0), "GB": ("GBP", 105.0), "AE": ("AED", 22.6),
           "SG": ("SGD", 62.0), "DE": ("EUR", 90.0), "TH": ("THB", 2.3)}
CCY = {"IN": ("INR", 1.0), **FOREIGN}
FX_TO_INR = {c: r for c, r in CCY.values()}       # currency -> INR per unit
ALL_FOREIGN = list(FOREIGN)

# (city, income factor, population weight)
CITIES = [("Delhi", 1.0, 20), ("Mumbai", 1.2, 18), ("Bengaluru", 1.15, 16),
          ("Hyderabad", 1.0, 10), ("Pune", 0.95, 9), ("Chennai", 0.95, 8),
          ("Kolkata", 0.85, 7), ("Jaipur", 0.75, 6), ("Lucknow", 0.7, 6)]

# local-hour (IST) traffic shape
HOUR_W = [1, .6, .4, .3, .3, .5, 1, 2, 3, 4, 5, 6,
          7, 7, 6, 6, 6, 7, 8, 9, 9, 7, 5, 3]

# synthetic securities / funds
SECURITIES = [
    ("RELIANCE", "Reliance Industries", "Energy", 2900), ("TCS", "Tata Consultancy Services", "IT", 3900),
    ("INFY", "Infosys", "IT", 1700), ("HDFCBANK", "HDFC Bank", "Financials", 1650),
    ("ICICIBANK", "ICICI Bank", "Financials", 1200), ("SBIN", "State Bank of India", "Financials", 800),
    ("ITC", "ITC", "FMCG", 450), ("HINDUNILVR", "Hindustan Unilever", "FMCG", 2400),
    ("LT", "Larsen & Toubro", "Industrials", 3600), ("BHARTIARTL", "Bharti Airtel", "Telecom", 1600),
    ("MARUTI", "Maruti Suzuki", "Auto", 12500), ("SUNPHARMA", "Sun Pharma", "Pharma", 1800),
    ("TATAMOTORS", "Tata Motors", "Auto", 900), ("ASIANPAINT", "Asian Paints", "Consumer", 2400),
    ("TITAN", "Titan Company", "Consumer", 3400),
]
# code, name, category, risk, nav, expense ratio %, 1y %, 3y % (all synthetic)
MF_SCHEMES = [
    ("ORN001", "Orion Liquid Fund", "liquid", "low", 3450.12, 0.20, 6.8, 6.5),
    ("ORN002", "Orion Short Duration Debt", "debt", "low", 42.31, 0.45, 7.4, 6.9),
    ("ORN003", "Orion Balanced Advantage", "hybrid", "moderate", 68.90, 0.85, 11.2, 12.0),
    ("ORN004", "Orion Nifty 50 Index", "index", "high", 188.40, 0.15, 13.5, 14.1),
    ("ORN005", "Orion Bluechip Fund", "large_cap", "high", 96.20, 0.95, 14.0, 14.8),
    ("ORN006", "Orion Flexi Cap Fund", "flexi_cap", "high", 74.55, 0.80, 16.2, 17.3),
    ("ORN007", "Orion ELSS Tax Saver", "elss", "very_high", 58.13, 0.90, 15.1, 16.0),
    ("ORN008", "Orion Midcap Fund", "mid_cap", "very_high", 131.70, 0.75, 21.3, 22.9),
    ("ORN009", "Orion Small Cap Fund", "small_cap", "very_high", 102.45, 0.70, 24.8, 27.4),
]
_SCHEME_BY_CODE = {s[0]: s for s in MF_SCHEMES}
# scheme preference weights by risk profile
_MF_W = {
    "conservative": {"ORN001": 20, "ORN002": 30, "ORN003": 20, "ORN004": 10, "ORN005": 10, "ORN006": 5, "ORN007": 5},
    "moderate":     {"ORN002": 8, "ORN003": 20, "ORN004": 20, "ORN005": 15, "ORN006": 20, "ORN007": 12, "ORN008": 5},
    "aggressive":   {"ORN004": 10, "ORN005": 8, "ORN006": 20, "ORN007": 10, "ORN008": 28, "ORN009": 24},
}


def _new_device():
    return str(uuid.uuid4())[:8]


def _weighted_sample(weights: dict, k: int):
    """k distinct keys, drawn without replacement, proportional to weights."""
    pool = dict(weights)
    out = []
    for _ in range(min(k, len(pool))):
        key = rnd.choices(list(pool), list(pool.values()))[0]
        out.append(key)
        del pool[key]
    return out


# ----------------------------------------------------------------------
# Personas
# ----------------------------------------------------------------------
def _make_customer(n):
    age = int(rnd.triangular(22, 62, 34))
    city, cf, _ = rnd.choices(CITIES, [c[2] for c in CITIES])[0]
    occupation = rnd.choices(["salaried", "self_employed", "business"], [70, 20, 10])[0]
    age_f = 0.75 + 0.5 * min((age - 22) / 18, 1.0)
    income = round(min(max(rnd.lognormvariate(math.log(62000), 0.6) * cf * age_f, 18000), 600000) / 500) * 500
    segment = "mass" if income < 50000 else "affluent" if income < 150000 else "premium"
    risk = rnd.choices(["conservative", "moderate", "aggressive"],
                       [20, 45, 35] if age < 30 else [25, 50, 25] if age < 45 else [50, 40, 10])[0]
    goal = rnd.choices(["emergency_fund", "home_purchase", "child_education",
                        "retirement", "wealth_creation", "travel"],
                       [15, 25, 5, 5, 35, 15] if age < 32 else
                       [10, 20, 25, 15, 25, 5] if age < 45 else
                       [5, 5, 20, 45, 20, 5])[0]

    favs = rnd.sample(CATEGORIES, 2)
    cat_w = [BASE_W[c] * (2.5 if c in favs else 1.0) for c in CATEGORIES]
    share = [w / sum(cat_w) for w in cat_w]
    scale = (income / 62000) ** 0.5
    mean_ticket = sum(s * MEDIAN_INR[c] for s, c in zip(share, CATEGORIES)) * scale \
        * math.exp(TICKET_SIGMA ** 2 / 2)
    monthly_card = income * rnd.uniform(0.15, 0.40)          # card share of income
    trip = None
    if rnd.random() < 0.20:                                  # one trip in/near the window
        start = NOW_MS - int(rnd.uniform(-20, 110) * DAY_MS)
        trip = (start, start + int(rnd.randint(4, 10) * DAY_MS), rnd.choice(ALL_FOREIGN))

    return {
        "id": f"CUST-{n}", "age": age, "city": city, "occupation": occupation,
        "income": income, "segment": segment, "risk": risk, "goal": goal,
        "credit_limit": max(round(income * rnd.uniform(2, 4), -3), 20000),
        "account_age_days": rnd.randint(60, 3000),
        "dependents": rnd.choices([0, 1, 2, 3], [40, 25, 25, 10])[0] if age > 27 else 0,
        "cat_w": cat_w, "scale": scale, "mean_ticket": mean_ticket,
        "monthly_card": monthly_card,
        "rate": monthly_card / mean_ticket,                  # expected card txns / month
        "cards": rnd.choices(CARD_TYPES, CARD_W, k=rnd.choice([1, 1, 2])),
        "devices": [_new_device() for _ in range(rnd.choice([1, 1, 2]))],
        "fav_merchants": {c: rnd.sample(MERCH_IN[c], 3) for c in CATEGORIES},
        "trip": trip,
    }


CUSTOMERS = [_make_customer(n) for n in range(1000, 10000)]     # CUST-1000..9999
_CUM = []
_acc = 0.0
for _c in CUSTOMERS:
    _acc += _c["rate"]
    _CUM.append(_acc)
TOTAL_MONTHLY_TXNS = _acc

_PENDING = []        # follow-up purchases belonging to a shopping/dining session


# ----------------------------------------------------------------------
# Event generation
# ----------------------------------------------------------------------
def _local(ts_ms):
    dt = datetime.fromtimestamp((ts_ms + IST_MS) / 1000, tz=timezone.utc)
    return dt.hour, dt.weekday() >= 5, dt.month


def _cat_mult(cat, hour, weekend, month):
    m = 1.0
    if cat == "dining":
        m *= 3.0 if hour in (12, 13, 14, 19, 20, 21, 22) else (0.3 if hour < 9 else 1.0)
    elif cat == "grocery":
        m *= (2.0 if hour in (17, 18, 19, 20) else 1.0) * (1.4 if weekend else 1.0)
    elif cat == "travel":
        m *= 1.6 if hour in (21, 22, 23, 0) else 1.0       # late-evening online bookings
    elif cat == "electronics":
        m *= 1.4 if hour >= 18 else 1.0
    elif cat == "retail":
        m *= 1.3 if weekend else 1.0
    if month in (10, 11) and cat in ("retail", "electronics"):
        m *= 1.4                                            # festive season
    return m


def _norm_factor(cat):
    """Traffic-weighted mean of _cat_mult, so time effects shift timing, not totals."""
    tot = sum(HOUR_W)
    return sum(HOUR_W[h] * (5 / 7 * _cat_mult(cat, h, False, 1) + 2 / 7 * _cat_mult(cat, h, True, 1))
               for h in range(24)) / tot


_MULT_NORM = {c: _norm_factor(c) for c in CATEGORIES}


def _pick_merchant(cust, cat, country):
    if country != "IN":
        return rnd.choice(MERCH_GLOBAL[cat])
    if rnd.random() < 0.65:
        return rnd.choice(cust["fav_merchants"][cat])
    pool = MERCH_IN[cat]
    return rnd.choices(pool, [1 / (i + 1) ** 0.8 for i in range(len(pool))])[0]


def _emit(cust, ts, cat, merchant, country, inr, device, card):
    hour, _, _ = _local(ts)
    ccy, rate = CCY[country]
    inr = min(max(inr, 10.0), 0.4 * cust["credit_limit"])
    # mild, observable upstream risk score (kept populated; the assistant does not depend on it)
    s = 0.03 + (0.12 if country != "IN" else 0) \
        + 0.10 * min(inr / (cust["mean_ticket"] * 8), 1.0) \
        + (0.05 if hour < 5 else 0) + (0.08 if device not in cust["devices"] else 0) \
        + rnd.gauss(0, 0.03)
    return {
        "transaction_id": str(uuid.uuid4()),
        "customer_id": cust["id"],
        "card_type": card,
        "timestamp": ts,
        "amount": round(inr / rate, 2),
        "currency": ccy,
        "merchant_name": merchant,
        "merchant_category": cat,
        "location_country": country,
        "is_international": country != "IN",
        "device_fingerprint": device,
        "fraud_risk_score": round(min(max(s, 0.0), 1.0), 2),
    }


def _in_trip(cust, ts):
    t = cust["trip"]
    return t[2] if t and t[0] <= ts <= t[1] else None


def _regular(ts):
    cust = CUSTOMERS[rnd.choices(range(len(CUSTOMERS)), cum_weights=_CUM)[0]]
    hour, weekend, month = _local(ts)
    cat = rnd.choices(CATEGORIES, [w * _cat_mult(c, hour, weekend, month) / _MULT_NORM[c]
                                   for w, c in zip(cust["cat_w"], CATEGORIES)])[0]
    country = _in_trip(cust, ts) or ("IN" if rnd.random() > 0.004 else rnd.choice(ALL_FOREIGN))
    merchant = _pick_merchant(cust, cat, country)
    if rnd.random() < 0.01:                                  # replaced phone
        cust["devices"].append(_new_device())
    device = rnd.choice(cust["devices"])
    card = rnd.choice(cust["cards"])
    inr = MEDIAN_INR[cat] * cust["scale"] * rnd.lognormvariate(0, TICKET_SIGMA)
    rec = _emit(cust, ts, cat, merchant, country, inr, device, card)

    # short sessions: a few related purchases within minutes (feeds 10-min windows)
    if rnd.random() < 0.12:
        due = ts
        for _ in range(rnd.randint(1, 3)):
            due += int(rnd.uniform(60, 480) * 1000)
            _PENDING.append({"due": due, "cust": cust, "cat": cat, "country": country,
                             "merchant": merchant if rnd.random() < 0.5 else None,
                             "device": device, "card": card})
    return rec


def _session_txn(p, ts):
    cust, cat, country = p["cust"], p["cat"], p["country"]
    merchant = p["merchant"] or _pick_merchant(cust, cat, country)
    inr = MEDIAN_INR[cat] * cust["scale"] * rnd.lognormvariate(-0.5, TICKET_SIGMA)
    return _emit(cust, ts, cat, merchant, country, inr, p["device"], p["card"])


def generate_transaction(ts_ms=None):
    """Drop-in replacement. Pass ts_ms (epoch ms) for backfills; omit for live."""
    ts = int(ts_ms if ts_ms is not None else time.time() * 1000)
    for p in _PENDING:
        if p["due"] <= ts:
            _PENDING.remove(p)
            return _session_txn(p, ts)
    return _regular(ts)


def generate_history(days=60, end_ms=None):
    """
    Event-time-ordered backfill. Volume is derived from the personas, so each
    customer's monthly card spend is consistent with their income.
    Payday-week and weekend effects are applied to daily volume.
    """
    end = int(end_ms if end_ms is not None else time.time() * 1000)
    first_midnight = ((end - days * DAY_MS + IST_MS) // DAY_MS) * DAY_MS - IST_MS
    base_daily = TOTAL_MONTHLY_TXNS / 30
    stamps = []
    for d in range(days):
        day0 = first_midnight + d * DAY_MS
        dt = datetime.fromtimestamp((day0 + IST_MS) / 1000, tz=timezone.utc)
        f = (1.25 if dt.day <= 7 else 0.8 if dt.day >= 25 else 0.95) \
            * (1.15 if dt.weekday() >= 5 else 0.94)
        hrs = rnd.choices(range(24), HOUR_W, k=int(base_daily * f))
        stamps += [day0 + int((h * 3600 + rnd.random() * 3600) * 1000) for h in hrs]
    stamps = sorted(t for t in stamps if t <= end)
    return [generate_transaction(t) for t in stamps]


# ----------------------------------------------------------------------
# Reference tables
# ----------------------------------------------------------------------
def build_reference_tables(as_of_ms=None):
    as_of = datetime.fromtimestamp((as_of_ms or NOW_MS) / 1000, tz=timezone.utc).date().isoformat()
    prof, pref, acct, demat, mfh, loans = [], [], [], [], [], []
    price = {s[0]: s[3] for s in SECURITIES}

    for c in CUSTOMERS:
        cid, inc, age, risk = c["id"], c["income"], c["age"], c["risk"]
        prof.append({"customer_id": cid, "age": age, "city": c["city"],
                     "occupation": c["occupation"], "income_monthly": inc,
                     "segment": c["segment"], "credit_limit": c["credit_limit"],
                     "account_age_days": c["account_age_days"], "risk_profile": risk,
                     "primary_goal": c["goal"], "dependents": c["dependents"],
                     "home_country": "IN"})
        interests = rnd.sample(["tax_saving", "mutual_funds", "direct_equity", "fixed_deposits",
                                "insurance", "retirement", "travel_planning"], rnd.randint(1, 3))
        pref.append({"customer_id": cid,
                     "preferred_language": rnd.choices(["English", "Hindi", "Hinglish"], [55, 35, 10])[0],
                     "advice_style": rnd.choice(["concise", "detailed"]),
                     "interests": ",".join(interests),
                     "monthly_budget_target": round(inc * rnd.uniform(0.45, 0.70), -2),
                     "savings_goal_pct": round(rnd.uniform(0.10, 0.30), 2)})

        # bank accounts
        cushion = rnd.lognormvariate(math.log(2.2), 0.7) * (1 + (age - 25) / 40)
        acct.append({"customer_id": cid, "account_type": "savings",
                     "balance": round(inc * cushion, -2), "as_of": as_of})
        if rnd.random() < 0.25 + (0.30 if risk == "conservative" else 0):
            acct.append({"customer_id": cid, "account_type": "fixed_deposit",
                         "balance": round(inc * rnd.uniform(3, 12), -3), "as_of": as_of})

        # mutual funds (SIP-driven)
        if age >= 24 and rnd.random() < 0.65:
            sip_total = max(round(inc * rnd.uniform(0.05, 0.18) / 500) * 500, 500)
            months = rnd.randint(6, 72)
            w = _MF_W[risk]
            codes = _weighted_sample(w, rnd.randint(1, 4))
            part = sip_total / len(codes)
            active = rnd.random() < 0.9
            for code in codes:
                nav = _SCHEME_BY_CODE[code][4]
                gain = min(max(rnd.gauss(0.10, 0.12), -0.25), 0.6)
                avg_nav = nav / (1 + gain)
                invested = part * months
                mfh.append({"customer_id": cid, "scheme_code": code,
                            "units": round(invested / avg_nav, 3), "avg_nav": round(avg_nav, 4),
                            "invested_amount": round(invested, 2),
                            "sip_amount": round(part / 100) * 100 if active else 0,
                            "sip_day": rnd.randint(1, 28)})

        # direct equity
        if rnd.random() < 0.25 + (0.35 if inc > 80000 else 0) + (0.15 if risk == "aggressive" else 0):
            budget = inc * rnd.uniform(2, 15)
            picks = rnd.sample(SECURITIES, rnd.randint(2, 10))
            ws = [rnd.random() + 0.2 for _ in picks]
            for (sym, _, _, px), wgt in zip(picks, ws):
                gain = min(max(rnd.gauss(0.12, 0.25), -0.4), 1.0)
                avg_px = px / (1 + gain)
                qty = max(int(budget * wgt / sum(ws) / avg_px), 1)
                demat.append({"customer_id": cid, "symbol": sym, "quantity": qty,
                              "avg_buy_price": round(avg_px, 2)})

        # loans (EMI burden capped so personas stay plausible)
        emi_cap, emi_used = 0.5 * inc, 0.0
        for kind, p, lo, hi, emi_f, r_lo, r_hi, cond in [
            ("home_loan", 0.35, 30, 90, 0.0095, 8.4, 9.6, age >= 30 and inc >= 50000),
            ("car_loan", 0.15, 4, 12, 0.025, 9.0, 11.0, age >= 26),
            ("personal_loan", 0.08, 2, 6, 0.045, 12.0, 16.0, True),
        ]:
            if cond and rnd.random() < p:
                out = inc * rnd.uniform(lo, hi)
                emi = out * emi_f
                if emi_used + emi <= emi_cap:
                    emi_used += emi
                    loans.append({"customer_id": cid, "loan_type": kind,
                                  "outstanding": round(out, -2), "emi": round(emi, -1),
                                  "interest_rate": round(rnd.uniform(r_lo, r_hi), 2)})

    return {
        "customer_profile": pd.DataFrame(prof),
        "customer_preferences": pd.DataFrame(pref),
        "bank_accounts": pd.DataFrame(acct),
        "demat_holdings": pd.DataFrame(demat),
        "mf_holdings": pd.DataFrame(mfh),
        "loans": pd.DataFrame(loans),
        "securities": pd.DataFrame(SECURITIES, columns=["symbol", "company_name", "sector", "price"]),
        "mf_schemes": pd.DataFrame(MF_SCHEMES, columns=["scheme_code", "scheme_name", "category",
                                                         "risk_level", "nav", "expense_ratio_pct",
                                                         "return_1y_pct", "return_3y_pct"]),
    }
